import { useEffect, useState } from "react";

const SessionTimer = () => {
  const INACTIVE_LIMIT = 15 * 60; // seconds
  const [timeLeft, setTimeLeft] = useState(INACTIVE_LIMIT);

  useEffect(() => {
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          sessionStorage.removeItem("token");
          window.location.href = "/session-expired";
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <div className="px-3 py-1 bg-red-50 text-red-600 rounded-lg text-xs font-bold">
      {minutes}:{seconds < 10 ? "0" : ""}
      {seconds}
    </div>
  );
};

export default SessionTimer;